-- Car Theft Career - Job Manager Extension Wrapper
-- This file wraps the job manager module for BeamNG's extension system

local M = require("carTheft/jobManager")
return M
