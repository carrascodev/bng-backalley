-- Car Theft Career - Main Extension Wrapper
-- This file wraps the main module for BeamNG's extension system

local M = require("carTheft/main")
return M
